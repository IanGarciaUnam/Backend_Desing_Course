
package com.product.api.dto;

public class DTOCategory{

    private Integer category_id;

    public DTOCategory(Integer category_id){
      this.category_id=category_id;
    }

    public Integer getCategory_id(){
      return this.category_id;
    }

    public void setStock(Integer stock){
      this.category_id=category_id;
    }
}
